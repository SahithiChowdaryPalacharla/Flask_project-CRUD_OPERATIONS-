from flask import Flask,render_template,request,redirect,session
from Model import db,Mobiles
from flask_migrate import Migrate

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///item.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
Migrate(app, db)

@app.before_first_request
def create_table():
    db.create_all()
@app.route("/home",methods=['GET','POST'])
def home():
    return render_template("image.html")

@app.route("/create", methods = ["GET","POST"])
def create():
    if request.method =='GET':
        return render_template("create.html")
    if request.method == 'POST':
        color = request.form.getlist('colors')
        colors=",".join(map(str, color))
        model_name = request.form['model_name']
        price = request.form['price']
        rating = request.form['rating']
        colors = colors

        iphones = Mobiles(
            model_name = model_name,
            price = price,
            rating = rating,
            colors = colors
        )
        db.session.add(iphones)
        db.session.commit()
        return redirect('/')
@app.route('/', methods=['GET'])
def RetriveList():
    iphones = Mobiles.query.all()
    return render_template('index.html',iphones = iphones)

@app.route('/<int:id>/edit', methods=['GET','POST'])

def update(id):
    iphone = Mobiles.query.filter_by(id=id).first()

    if request.method == 'POST':
            if iphone:
                db.session.delete(iphone)
                db.session.commit()


                color=request.form.getlist('colors')
                colors = ",".join(map(str,color))
                model_name = request.form['model_name']
                price = request.form['price']
                rating = request.form['rating']
                colors = colors

                iphone = Mobiles(
                    model_name = model_name,
                    price = price,
                    rating = rating,
                    colors = colors
                )
                db.session.add(iphone)
                db.session.commit()
                return redirect('/')
            return f"student with id ={id} Does not exist"


    return render_template('update.html',iphone = iphone)



@app.route('/<int:id>/delete', methods=['GET','POST'])
def delete(id):
    iphones = Mobiles.query.filter_by(id=id).first()
    if request.method == 'POST':
        if iphones:
            db.session.delete(iphones)
            db.session.commit()
            return redirect('/')
        abort(404)
    #return redirect('/')
    return render_template('delete.html')

app.run(debug=True)
