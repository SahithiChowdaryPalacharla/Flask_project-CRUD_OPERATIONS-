from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

class Mobiles(db.Model):
    __tablename__ = "iphones"

    id = db.Column(db.Integer, primary_key=True)
    model_name = db.Column(db.String())
    colors = db.Column(db.String())
    price = db.Column(db.String())
    rating= db.Column(db.Integer())

    def __init__(self,model_name,colors,price,rating):
        self.model_name = model_name
        self.colors = colors
        self.price = price
        self.rating = rating

    def __repr__(self):
            return f"{self.model_name}:{self.price}"
